import sys
sys.path.insert(0, 'c:\\dev\\sly\\')
from sly import Lexer, Parser

class HeroLabLexer(Lexer):

    tokens = { 
        NL,
        PLUS, MINUS,
    }

    # String containing ignored characters between tokens
    ignore = ' \t'

    PLUS = r'\+'
    MINUS = r'-'
    NL = r'\n'
    
    def error(self, t):
        print("Illegal character '%s'" % t.value[0])
        self.index += 1

class HeroLabParser(Parser):
    # Get the token list from the lexer (required)
    tokens = HeroLabLexer.tokens

    debugfile = 'HeroLab 2.out'
    dotfile = "HeroLab 2.dot"

    @_('script_ends_nl', 'script_ends_stmt')
    def script(self, p):
        return p[0]

    @_('')
    def script_ends_nl(self, p):
        return []

    @_(' script_ends_nl   NL ',
       ' script_ends_stmt NL ')
    def script_ends_nl(self, p):
        return p[0]

    @_('script_ends_nl statement')
    def script_ends_stmt(self, p):
        return p.script_ends_nl + [p.statement]

    @_('PLUS', 'MINUS')
    def statement(self, p):
        return p[0]

if __name__ == '__main__':
    lexer = HeroLabLexer()
    
    data = '''567:
    
    var myID as number
    var myID2 as string

    myID = 567
    myID2 = myID

    this.field.subfield[5, "thin mint"].bob = "Hello!"
    '''

    data2 = '''-
    +'''
    tokens = lexer.tokenize(data2)
    
    parser = HeroLabParser()
    result = parser.parse(tokens)
    print (result)

    data2 = '''
    +
    -'''
    tokens = lexer.tokenize(data2)
    
    parser = HeroLabParser()
    result = parser.parse(tokens)
    print (result)
    
    data2 = '''+
    -
    '''
    tokens = lexer.tokenize(data2)
    
    parser = HeroLabParser()
    result = parser.parse(tokens)
    print (result)
    
    data2 = ''''''
    tokens = lexer.tokenize(data2)
    
    parser = HeroLabParser()
    result = parser.parse(tokens)
    print (result)