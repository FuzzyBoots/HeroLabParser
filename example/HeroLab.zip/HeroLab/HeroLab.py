import sys
sys.path.insert(0, 'c:\\dev\\sly\\')
from sly import Lexer, Parser

class HeroLabLexer(Lexer):
    keywords = (
        'if','goto','then','else','elsif','endif','while','loop','for','to','next','done','doneif','perform','debug','foreach','nexteach','eachthing','pick','thing','bootstrap','actor','portfolio','in','where','sortas','notify','append','trustme','var','as','number','string','this','count','high','low','val','fieldval', 'TRUE', 'FALSE'
    )

    tokens = { 
        NEWLINE,
        PLUS, MINUS, TIMES, DIVIDE, CONCAT, EQUAL, MOD, 
        PLUSEQUAL, MINUSEQUAL, TIMESEQUAL, DIVIDEEQUAL, CONCATEQUAL, MODEQUAL, 
        LPAREN, RPAREN, LSQUARE, RSQUARE, DOT, 
        LT, LE, GT, GE, NE, NOT, COLON,
        COMMA, PERCENT, FLOAT, QUESTION, SCONST,
        ID, NEWLINE,  AT, OR, XOR, TRANSITION, REFERENCE,
        IF,GOTO,THEN,ELSE,ELSIF,ENDIF,WHILE,LOOP,FOR,TO,NEXT,DONE,
        DONEIF,PERFORM,DEBUG,FOREACH,NEXTEACH,EACHTHING,PICK,THING,BOOTSTRAP,
        ACTOR,PORTFOLIO,IN,WHERE,SORTAS,NOTIFY,APPEND,TRUSTME,VAR,AS,
        NUMBER,STRING,THIS,COUNT,HIGH,LOW,VAL,FIELDVAL, TRUE, FALSE,
        COMMENT, MACRO,
        IF, GOTO, THEN, ELSE, ELSIF, ENDIF, WHILE, LOOP, FOR, TO, NEXT, DONE, DONEIF, PERFORM, DEBUG, FOREACH, NEXTEACH, EACHTHING, PICK, THING, BOOTSTRAP, ACTOR, PORTFOLIO, IN, WHERE, SORTAS, NOTIFY, APPEND, TRUSTME, VAR, AS, NUMBER, STRING, THIS, COUNT, HIGH, LOW, VAL, FIELDVAL, TRUE, FALSE
    }

    # String containing ignored characters between tokens
    ignore = ' \t'

    COMMENT = r'~ .*'

    FLOAT = r'((\d*\.\d+)(E[\+-]?\d+)?|([1-9]\d*E[\+-]?\d+))'

    # String literal
    SCONST = r'\"([^\\\n]|(\\.))*?\"'

    def SCONST(self, t):
        t.value = t.value[1:-1] #Strip the quotation marks
        return t

    MACRO=r'\#[A-Za-z0-9_]+'

    # Base ID rule
    ID = r'[a-zA-Z0-9_]+'

    ID['if'] = IF
    ID['goto'] = GOTO
    ID['then'] = THEN
    ID['else'] = ELSE
    ID['elsif'] = ELSIF
    ID['endif'] = ENDIF
    ID['while'] = WHILE
    ID['loop'] = LOOP
    ID['for'] = FOR
    ID['to'] = TO
    ID['next'] = NEXT
    ID['done'] = DONE
    ID['doneif'] = DONEIF
    ID['perform'] = PERFORM
    ID['debug'] = DEBUG
    ID['foreach'] = FOREACH
    ID['nexteach'] = NEXTEACH
    ID['eachthing'] = EACHTHING
    ID['pick'] = PICK
    ID['thing'] = THING
    ID['bootstrap'] = BOOTSTRAP
    ID['actor'] = ACTOR
    ID['portfolio'] = PORTFOLIO
    ID['in'] = IN
    ID['where'] = WHERE
    ID['sortas'] = SORTAS
    ID['notify'] = NOTIFY
    ID['append'] = APPEND
    ID['trustme'] = TRUSTME
    ID['var'] = VAR
    ID['as'] = AS
    ID['number'] = NUMBER
    ID['string'] = STRING
    ID['this'] = THIS
    ID['count'] = COUNT
    ID['high'] = HIGH
    ID['low'] = LOW
    ID['val'] = VAL
    ID['fieldval'] = FIELDVAL
    ID['TRUE'] = TRUE
    ID['FALSE'] = FALSE

    COLON = r':'
    EQUAL = r'='
    PLUSEQUAL = r'\+='
    MINUSEQUAL = r'-='
    TIMESEQUAL = r'\*='
    DIVIDEEQUAL = r'/='
    MODEQUAL = r'%='
    CONCATEQUAL = r'&='
    PLUS = r'\+'
    MINUS = r'-'
    TIMES = r'\*'
    DIVIDE = r'/'
    MOD = r'%'
    CONCAT = r'&'
    LPAREN = r'\('
    RPAREN = r'\)'
    LSQUARE = r'\['
    RSQUARE = r'\]'
    DOT = r'\.'
    LT = r'<'
    LE = r'<='
    GT = r'>'
    GE = r'>='
    NE = r'!='
    COMMA = r'\,'
    PERCENT = r'%'
    QUESTION = r'\?'
    OR = r'\|'
    XOR = r'\^'
    NOT = r'\!'
    AT = r'@'
    NEWLINE = r'\n'
    
    def error(self, t):
        print("Illegal character '%s'" % t.value[0])
        self.index += 1

class HeroLabParser(Parser):
    # Get the token list from the lexer (required)
    tokens = HeroLabLexer.tokens

    precedence = (
        ('left', 'PLUS', 'MINUS'),
        ('left', 'TIMES', 'DIVIDE', 'MOD'),
        ('left', 'CONCAT'),
        ('right', 'UMINUS')
    )

    debugfile = 'HeroLab.out'
    dotfile = "HeroLab.dot"

    @_('script_ends_nl', 'script_ends_stmt')
    def script(self, p):
        return p[0]

    @_('')
    def script_ends_nl(self, p):
        return []

    @_(' script_ends_nl   NEWLINE ',
       ' script_ends_stmt NEWLINE ')
    def script_ends_nl(self, p):
        return p[0]

    @_('script_ends_nl statement')
    def script_ends_stmt(self, p):
        return p.script_ends_nl + [p.statement]

    @_('label')
    def statement(self, p):
        return p.label

    @_('declaration')
    def statement(self, p):
        return p.declaration

    @_('assignment')
    def statement(self, p):
        return p.assignment

    @_('ID COLON')
    def label(self, p):
        return ('LABEL', p.ID)

    @_('VAR ID AS NUMBER', 
       'VAR ID AS STRING')
    def declaration(self, p):
        return ('DECLARE', p.ID, p[3])

    @_( 'reference EQUAL expression')
    def assignment(self, p):
        return ('ASSIGN', p.reference, p.expression)

    @_( 'expression PLUS expression',
        'expression MINUS expression',
        'expression TIMES expression',
        'expression DIVIDE expression',
        'expression MOD expression',
        'expression CONCAT expression')
    def expression(self, p):
        return ('BINOP', p[1], p[0], p[2])

    @_( 'ID', 'field_ref')
    def reference(self, p):
        return p[0]

    @_( 'reference PLUSEQUAL expression',
        'reference MINUSEQUAL expression',
        'reference TIMESEQUAL expression',
        'reference DIVIDEEQUAL expression',
        'reference MODEQUAL expression',
        'reference CONCATEQUAL expression')
    def assignment(self, p):
        return ('ASSIGNOP', p[1], p.reference, p.expression)

    @_('LPAREN expression RPAREN')
    def expression(self, p):
        return ('GROUP', p.expression)

    @_('MINUS expression %prec UMINUS')
    def expression(self, p):
        return ('UNARY', '-', p.expression)

    @_('ID')
    def expression(self, p):
        return ('ID', p.ID)

    @_('NUMBER')
    def expression(self, p):
        return ('NUMBER', p.NUMBER)

    @_('FLOAT')
    def expression(self, p):
        return ('FLOAT', p.NUMBER)

    @_('SCONST')
    def expression(self, p):
        return ('STRING', p.SCONST)

    @_('THIS DOT transition', 'transition')
    def field_ref(self, p):
        return ('FIELD_REF', p.transition)

    @_('DOT transition')
    def dotexpr(self, p):
        return p.transition

    @_('ID')
    def transition(self, p):
        return ('REFERENCE', [], p.ID)

    @_('ID LSQUARE paramlist RSQUARE')
    def transition(self, p):
        return ('REFERENCE', p.paramlist, p.ID)

    @_('ID dotexpr')
    def transition(self, p):
        return ('TRANSITION', [], p.ID, p.dotexpr)

    @_('ID LSQUARE paramlist RSQUARE dotexpr')
    def transition(self, p):
        return ('TRANSITION', p.paramlist, p.ID, p.dotexpr)

    @_('expression { COMMA expression }') 
    def paramlist(self, p):
        return [p.expression0] + p.expression1

    @_( 'expression LT expression',
        'expression LE expression',
        'expression GT expression',
        'expression GE expression',
        'expression NE expression',
        'expression EQUAL expression')
    def expr_comp(self, p):
        return ('COMPOP', p[1], p.expression0, p.expression1)

if __name__ == '__main__':
    lexer = HeroLabLexer()
    
    data = '''567:
    
    var myID as number
    var myID2 as string

    myID = 567
    myID2 = myID

    this.field.subfield[5, "thin mint"].bob = "Hello!"
    '''

    data2 = '''this.thing[id].portal.field = 5'''
    tokens = lexer.tokenize(data2)
    tokens_bak = lexer.tokenize(data2)
    for tok in tokens_bak:
        print('type=%r, value=%r' % (tok.type, tok.value))

    parser = HeroLabParser()
    result = parser.parse(tokens)
    print (result)